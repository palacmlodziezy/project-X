﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour {

    private Rigidbody2D Fizyka;
	// Use this for initialization
	void Start ()
    {
        Fizyka = GetComponent<Rigidbody2D>();
	}
    public float movementSpeed = 10;
        
        void Update ()
    {
        if (Input.GetKey("up")|| Input.GetKey("w"))
        {
            Fizyka.velocity=new Vector2()
            print("up arrow key is held down");
            //transform.Translate(Vector3.up * movementSpeed * Time.deltaTime);
        }

        if (Input.GetKey("down") || Input.GetKey("s"))
        {
            print("down arrow key is held down");
           //transform.Translate(Vector3.down * movementSpeed * Time.deltaTime);
        }
        if (Input.GetKey("left") || Input.GetKey("a"))
        {
            print("left arrow key is held down");
           // transform.Translate(Vector3.left * movementSpeed * Time.deltaTime);
        }

        if (Input.GetKey("right") || Input.GetKey("d"))
        {
            print("right arrow key is held down");
            //transform.Translate(Vector3.right * movementSpeed * Time.deltaTime);
        }
    }
}
